/* global vc, i18nLocale */
(function ( $ ) {
	'use strict';
	vc.HelperPanelTabs = {};
})( window.jQuery );